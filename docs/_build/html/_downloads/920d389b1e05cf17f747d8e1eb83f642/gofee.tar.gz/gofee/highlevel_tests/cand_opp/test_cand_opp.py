import numpy as np

from ase.io import read, write
from ase.constraints import FixAtoms

from gofee.candidates import RattleMutation, RattleMutation1, RattleMutation2, RattleMutationLocal, PermutationMutation

a0 = read('test.traj', index='0')
indices_fixed = []
for c in a0.constraints:
    if isinstance(c, FixAtoms):
        indices_fixed = c.get_indices()

n_to_optimize = a0.get_number_of_atoms() - len(indices_fixed)
print(n_to_optimize)

rattle = RattleMutation1(n_to_optimize, Nrattle=3, rattle_range=3)

structures = []
for i in range(20):
    print(i)
    a = rattle.get_new_candidate([a0])
    structures += [a0.copy(), a]
write('mutated.traj', structures)